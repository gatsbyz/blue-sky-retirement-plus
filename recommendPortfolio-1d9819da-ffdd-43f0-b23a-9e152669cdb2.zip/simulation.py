from dotenv import load_dotenv
import alpaca_trade_api as tradeapi
import os
import numpy as np
import pandas as pd

# from MCForecastTools import MCSimulation

import pandas as pd



def create_savings_dataframe(savings, total_stocks_bonds):
    # Step 1: Create a Python list named savings_data that has two elements.
    # The first element contains the total value of the cryptocurrency wallet. 
    # The second element contains the total value of the stock and bond portions of the portfolio.

    # Consolidate financial assets data into a Python list
    savings_data=[]

    savings_data.append(savings)
    savings_data.append(total_stocks_bonds)

    # Step 2: Use the savings_data list to create a Pandas DataFrame named savings_df, and then display this DataFrame.
    # The function to create the DataFrame should take the following three parameters:

    # savings_data: Use the list that you just created.
    # columns: Set this parameter equal to a Python list with a single value called amount.
    # index: Set this parameter equal to a Python list with the values of crypto and stock/bond.

    # Create a Pandas DataFrame called savings_df 
    index=["cash", "stock/bond"]
    columns=["amount"]
    savings_df = pd.DataFrame(savings_data , columns=columns, index=index)
    return savings_df


def get_portfolio_dataframe():
    ### Get data from Alpaca for MC Simulation of retirement portfolio.

    load_dotenv()

    # Set the variables for the Alpaca API and secret keys
    alpaca_api_key = os.getenv("ALPACA_API_KEY")
    alpaca_secret_key = os.getenv("ALPACA_SECRET_KEY")

    # Create the Alpaca tradeapi.REST object
    alpaca = tradeapi.REST(
        alpaca_api_key,
        alpaca_secret_key,
        api_version="v2")

    # Step 3: Make an API call via the Alpaca SDK to get 3 years of historical closing prices for a traditional 60/40 portfolio split:
    # 60% stocks (SPY) and 40% bonds (AGG).

    # Set start and end dates of 3 years back from your current date
    # Alternatively, you can use an end date of 2020-08-07 and work 3 years back from that date 
    start_date = pd.Timestamp("2019-04-22", tz="America/New_York").isoformat()
    end_date = pd.Timestamp("2022-04-22", tz="America/New_York").isoformat()

    # Set number of rows to 1000 to retrieve the maximum amount of rows
    limit_rows=10000

    # Use the Alpaca get_bars function to make the API call to get the 3 years worth of pricing data
    # The tickers and timeframe parameters should have been set in Part 1 of this activity 
    # The start and end dates should be updated with the information set above
    # Remember to add the df property to the end of the call so the response is returned as a DataFrame
    timeframe="1Day"
    tickers=["SPY", "AGG"]
    df_portfolio = alpaca.get_bars(
        tickers,
        timeframe,
        start = start_date,
        end = end_date,
        limit=limit_rows
    ).df

    # Reorganize the DataFrame
    # Separate ticker data
    SPY = df_portfolio[df_portfolio['symbol']=='SPY'].drop('symbol', axis=1)
    AGG = df_portfolio[df_portfolio['symbol']=='AGG'].drop('symbol', axis=1)


    # Concatenate the ticker DataFrames
    df_portfolio = pd.concat([SPY,AGG],axis=1, keys=['SPY','AGG'])
    return df_portfolio


# Step 4: Run a Monte Carlo simulation of 500 samples and 30 years for the 60/40 portfolio, and then plot the results.
# Configure the Monte Carlo simulation to forecast 30 years cumulative returns
# The weights should be split 40% to FXNAX and 60% to SPY.
# Run 500 samples.
def run_mc_output(df_portfolio, portfolio_type, years_to_retirement):
    df_portfolio = get_portfolio_dataframe()
    if portfolio_type == 'Moderate':
        MonteCarlo_output = MCSimulation(
            portfolio_data = df_portfolio,
            weights = [.63,.37],
            num_simulation = 40,
            num_trading_days = 252*years_to_retirement)
        
    elif portfolio_type == "Conservative":
        MonteCarlo_output = MCSimulation(
            portfolio_data = df_portfolio,
            weights = [.29,.71],
            num_simulation = 40,
            num_trading_days = 252*years_to_retirement)
        
    else:
        MonteCarlo_output = MCSimulation(
            portfolio_data = df_portfolio,
            weights = [.44,.56],
            num_simulation = 40,
            num_trading_days = 252*years_to_retirement)
    MonteCarlo_output.portfolio_data.dropna()
    return MonteCarlo_output

def summary_statistics(output):
    return output.summarize_cumulative_return()

def mean_cumulative_return(output, total_stocks_bonds):
    return summary_statistics(output)[5] * float(total_stocks_bonds)

def savings_at_retirement(mean_cumulative_return, savings):
    return float(mean_cumulative_return + savings)

def get_retirement_cities(output, data, retirement_years, total_stocks_bonds, savings):

    mean_cumulative_return_val =  mean_cumulative_return(output, total_stocks_bonds)
    savings_at_retirement_val = savings_at_retirement(mean_cumulative_return_val, savings)

    retirement_cities = []
            
    for item in data:
        if savings_at_retirement_val >= (item['estimated_monthly_costs_with_rent'] * (retirement_years * 12)):                
            retirement_cities.append(item['city'] + '/' + item['country']) 

    return retirement_cities
    

class MCSimulation:
    """
    A Python class for runnning Monte Carlo simulation on portfolio price data. 
    
    ...
    
    Attributes
    ----------
    portfolio_data : pandas.DataFrame
        portfolio dataframe
    weights: list(float)
        portfolio investment breakdown
    nSim: int
        number of samples in simulation
    nTrading: int
        number of trading days to simulate
    simulated_return : pandas.DataFrame
        Simulated data from Monte Carlo
    confidence_interval : pandas.Series
        the 95% confidence intervals for simulated final cumulative returns
        
    """
    
    def __init__(self, portfolio_data, weights="", num_simulation=1000, num_trading_days=252):
        """
        Constructs all the necessary attributes for the MCSimulation object.

        Parameters
        ----------
        portfolio_data: pandas.DataFrame
            DataFrame containing stock price information from Alpaca API
        weights: list(float)
            A list fractions representing percentage of total investment per stock. DEFAULT: Equal distribution
        num_simulation: int
            Number of simulation samples. DEFAULT: 1000 simulation samples
        num_trading_days: int
            Number of trading days to simulate. DEFAULT: 252 days (1 year of business days)
        """
        
        # Check to make sure that all attributes are set
        if not isinstance(portfolio_data, pd.DataFrame):
            raise TypeError("portfolio_data must be a Pandas DataFrame")
            
        # Set weights if empty, otherwise make sure sum of weights equals one.
        if weights == "":
            num_stocks = len(portfolio_data.columns.get_level_values(0).unique())
            weights = [1.0/num_stocks for s in range(0,num_stocks)]
        else:
            if round(sum(weights),2) < .99:
                raise AttributeError("Sum of portfolio weights must equal one.")
        
        # Calculate daily return if not within dataframe
        if not "daily_return" in portfolio_data.columns.get_level_values(1).unique():
            close_df = portfolio_data.xs('close',level=1,axis=1).pct_change()
            tickers = portfolio_data.columns.get_level_values(0).unique()
            column_names = [(x,"daily_return") for x in tickers]
            close_df.columns = pd.MultiIndex.from_tuples(column_names)
            portfolio_data = portfolio_data.merge(close_df,left_index=True,right_index=True).reindex(columns=tickers,level=0)    
        
        # Set class attributes
        self.portfolio_data = portfolio_data
        self.weights = weights
        self.nSim = num_simulation
        self.nTrading = num_trading_days
        self.simulated_return = ""
        
    def calc_cumulative_return(self):
        """
        Calculates the cumulative return of a stock over time using a Monte Carlo simulation (Brownian motion with drift).

        """
        
        # Get closing prices of each stock
        last_prices = self.portfolio_data.xs('close',level=1,axis=1)[-1:].values.tolist()[0]
        
        # Calculate the mean and standard deviation of daily returns for each stock
        daily_returns = self.portfolio_data.xs('daily_return',level=1,axis=1)
        mean_returns = daily_returns.mean().tolist()
        std_returns = daily_returns.std().tolist()
        
        # Initialize empty Dataframe to hold simulated prices
        portfolio_cumulative_returns = pd.DataFrame()
        
        # Run the simulation of projecting stock prices 'nSim' number of times
        for n in range(self.nSim):
        
            if n % 10 == 0:
                print(f"Running Monte Carlo simulation number {n}.")
        
            # Create a list of lists to contain the simulated values for each stock
            simvals = [[p] for p in last_prices]
    
            # For each stock in our data:
            for s in range(len(last_prices)):

                # Simulate the returns for each trading day
                for i in range(self.nTrading):
        
                    # Calculate the simulated price using the last price within the list
                    simvals[s].append(simvals[s][-1] * (1 + np.random.normal(mean_returns[s], std_returns[s])))
    
            # Calculate the daily returns of simulated prices
            sim_df = pd.DataFrame(simvals).T.pct_change()
    
            # Use the `dot` function with the weights to multiply weights with each column's simulated daily returns
            sim_df = sim_df.dot(self.weights)
    
            # Calculate the normalized, cumulative return series
            portfolio_cumulative_returns[n] = (1 + sim_df.fillna(0)).cumprod()
        
        # Set attribute to use in plotting
        self.simulated_return = portfolio_cumulative_returns
        
        # Calculate 95% confidence intervals for final cumulative returns
        self.confidence_interval = portfolio_cumulative_returns.iloc[-1, :].quantile(q=[0.025, 0.975])
        
        return portfolio_cumulative_returns
    
    def plot_simulation(self):
        """
        Visualizes the simulated stock trajectories using calc_cumulative_return method.

        """ 
        
        # Check to make sure that simulation has run previously. 
        if not isinstance(self.simulated_return,pd.DataFrame):
            self.calc_cumulative_return()
            
        # Use Pandas plot function to plot the return data
        plot_title = f"{self.nSim} Simulations of Cumulative Portfolio Return Trajectories Over the Next {self.nTrading} Trading Days."
        return self.simulated_return.plot(legend=None,title=plot_title)
    
    def plot_distribution(self):
        """
        Visualizes the distribution of cumulative returns simulated using calc_cumulative_return method.

        """
        
        # Check to make sure that simulation has run previously. 
        if not isinstance(self.simulated_return,pd.DataFrame):
            self.calc_cumulative_return()
        
        # Use the `plot` function to create a probability distribution histogram of simulated ending prices
        # with markings for a 95% confidence interval
        plot_title = f"Distribution of Final Cumuluative Returns Across All {self.nSim} Simulations"
        plt = self.simulated_return.iloc[-1, :].plot(kind='hist', bins=10,density=True,title=plot_title)
        plt.axvline(self.confidence_interval.iloc[0], color='r')
        plt.axvline(self.confidence_interval.iloc[1], color='r')
        return plt
    
    def summarize_cumulative_return(self):
        """
        Calculate final summary statistics for Monte Carlo simulated stock data.
        
        """
        
        # Check to make sure that simulation has run previously. 
        if not isinstance(self.simulated_return,pd.DataFrame):
            self.calc_cumulative_return()
            
        metrics = self.simulated_return.iloc[-1].describe()
        ci_series = self.confidence_interval
        ci_series.index = ["95% CI Lower","95% CI Upper"]
        return metrics.append(ci_series)